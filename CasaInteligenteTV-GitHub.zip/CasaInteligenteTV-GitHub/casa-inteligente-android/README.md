# Casa Inteligente TV — projeto Android

Projeto Android que abre o painel HTML local em uma WebView, pensado para Android TV / Mi TV Stick. O HTML original está em `app/src/main/assets/index.html`.

## Gerar o APK pelo GitHub Actions

1. Baixe e descompacte este projeto no computador.
2. Entre em sua conta do GitHub e crie um repositório novo (por exemplo, `casa-inteligente-tv`).
3. Envie **todo o conteúdo desta pasta** para a raiz do repositório, incluindo a pasta oculta `.github/workflows`.
   - Pelo site do GitHub, use **Add file → Upload files**. Se a interface não permitir enviar a pasta oculta, use GitHub Desktop ou Git no computador para enviar todos os arquivos.
4. Abra a aba **Actions** do repositório e selecione **Gerar APK Android TV**.
5. Clique em **Run workflow** e confirme. O fluxo também roda automaticamente em novos envios para as branches `main` ou `master`.
6. Quando terminar com sucesso (ícone verde), abra a execução e, na seção **Artifacts**, baixe `CasaInteligenteTV-debug-apk`.
7. Descompacte o artefato. Dentro dele estará `app-debug.apk`. Copie para o Mi TV Stick e instale-o.

O workflow compila com Java 17, Gradle 8.9 e Android Gradle Plugin 8.7.3. O APK gerado é uma **versão debug**, adequada para teste e instalação manual; não é um APK assinado para publicação na Play Store.

## O que contém

- `app/src/main/assets/index.html`: painel HTML local.
- `MainActivity.java`: WebView em tela cheia, armazenamento DOM e tela sempre ativa.
- `BootReceiver.java`: tentativa de iniciar o app após eventos de boot/substituição do pacote.
- `AndroidManifest.xml`: permissões e categorias de inicialização Android TV/launcher.
- `.github/workflows/android-apk.yml`: compilação automática e publicação do APK como artefato.

## Observações importantes

- O projeto não inclui seu endereço/token do Home Assistant; configure-os na tela inicial do painel.
- A abertura automática após reiniciar depende da versão do Android/firmware e das restrições do fabricante. O receiver está incluído, mas alguns aparelhos/launchers impedem que um app abra sua Activity sozinho após o boot. Se isso ocorrer, será necessário configurar o início automático no aparelho ou usar um launcher/kiosk compatível.
- O alerta do Frigate e a rotação estão no HTML original, mas devem ser testados no dispositivo real com seu Home Assistant/MQTT.
- O ambiente de criação deste pacote não tinha Android SDK/Gradle para compilar localmente; o GitHub Actions fará a compilação na nuvem.

## Dashboard de energia solar Deye

O painel inclui uma tela `solar` no rodízio automático que carrega o endereço local configurado:
`http://192.168.3.46:3030/embed`.

O dispositivo Android TV precisa estar na mesma rede local e conseguir acessar esse endereço. A exibição depende de o servidor da dashboard permitir incorporação em iframe; se houver bloqueio por `X-Frame-Options`/CSP, será necessário ajustar o servidor da dashboard. O tempo da tela solar segue o intervalo geral do rodízio configurado no painel.
